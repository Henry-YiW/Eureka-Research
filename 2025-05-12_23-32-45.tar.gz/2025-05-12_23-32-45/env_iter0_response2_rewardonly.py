@torch.jit.script
def compute_reward(current_palm_displacement: torch.Tensor, target_displacement: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    Calculate the reward for the ShadowHandRope task with the goal of making the rope slide through 
    a fixed shadow hand to reach a target displacement.

    Args:
    - current_palm_displacement (torch.Tensor): The current displacement of the palm from the rope along the rope's y-axis.
    - target_displacement (torch.Tensor): The desired target displacement the agent aims to achieve.

    Returns:
    - Tuple containing:
        - Total reward (torch.Tensor)
        - Dictionary of individual reward components (Dict[str, torch.Tensor])
    """
    # Temperature parameters for reward transformation
    distance_temp = torch.tensor(5.0, device=current_palm_displacement.device) 

    # Reward component: Negative of the squared error from the target displacement
    displacement_error = torch.norm(current_palm_displacement - target_displacement)
    reward_displacement = torch.exp(-distance_temp * displacement_error**2)

    # Aggregate reward
    total_reward = reward_displacement

    # Dictionary of individual reward components
    reward_components = {'displacement_reward': reward_displacement}

    return total_reward, reward_components
