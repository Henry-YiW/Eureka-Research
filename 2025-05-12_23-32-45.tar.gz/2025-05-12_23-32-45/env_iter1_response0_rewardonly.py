@torch.jit.script
def compute_reward(rope_pos: torch.Tensor, palm_pos: torch.Tensor, rope_rot: torch.Tensor, current_palm_displacement: torch.Tensor, target_displacement: float) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    # Displacement-based reward
    displacement_reward_temp = 1.0  # Temperature parameter to scale the exponential reward
    displacement_error = torch.abs(current_palm_displacement - target_displacement)
    displacement_reward = torch.exp(-displacement_reward_temp * displacement_error)
    
    # Position stability reward (to encourage minimal unnecessary movement)
    palm_stability_temp = 0.5  # Temperature parameter for palm position stability
    palm_velocity_penalty = torch.norm(palm_pos - rope_pos, dim=-1)  # ensure the palm stays close to the rope
    palm_stability_reward = torch.exp(-palm_stability_temp * palm_velocity_penalty)
    
    # Combine rewards
    total_reward = displacement_reward + palm_stability_reward
    
    reward_components = {
        "displacement_reward": displacement_reward,
        "palm_stability_reward": palm_stability_reward
    }
    
    return total_reward, reward_components
