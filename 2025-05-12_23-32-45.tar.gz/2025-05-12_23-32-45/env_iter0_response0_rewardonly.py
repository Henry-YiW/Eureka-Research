@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_displacement: float) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Define a temperature variable for scaling and shaping the reward
    temperature: float = 0.1
    
    # Compute the squared difference between the current displacement and the target displacement
    displacement_error = torch.pow(current_palm_displacement - target_displacement, 2)
    
    # Create an exponential reward directly proportional to the negative of the error,
    # scaled by the temperature. The closer the displacement is to the target, the less the error,
    # the larger the exponential reward.
    displacement_reward = torch.exp(-displacement_error / temperature)
    
    # Aggregate individual components, if needed, for logging or debugging purposes
    reward_components = {
        "displacement_reward": displacement_reward,
        "displacement_error": displacement_error
    }
    
    # Total reward to be maximized
    total_reward = displacement_reward
    
    return total_reward, reward_components
