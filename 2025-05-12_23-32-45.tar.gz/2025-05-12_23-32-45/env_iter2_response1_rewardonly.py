@torch.jit.script
def compute_reward(current_displacement: Tensor, target_displacement: float) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Define the temperature for exponential transformation
    temperature: float = 0.1

    # Calculate the negative absolute error between current and target displacement
    abs_error: Tensor = torch.abs(current_displacement - target_displacement)
    error_reward: Tensor = -abs_error

    # Apply an exponential transformation to the error reward with a temperature
    exp_reward: Tensor = torch.exp(error_reward / temperature)

    # Compute total reward
    reward = exp_reward

    # Dictionary of individual components for debugging purposes
    reward_components: Dict[str, Tensor] = {
        "error_reward": error_reward,
        "exp_reward": exp_reward
    }

    return reward, reward_components
