@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_displacement: float) -> Tuple[Tensor, Dict[str, Tensor]]:
    """
    Reward function to encourage the rope to slide through a fixed shadow hand to reach a target displacement.

    :param current_palm_displacement: The current displacement of the palm position from its initial position along the rope's y-axis.
    :param target_displacement: The target displacement value the agent needs to achieve.
    :return: A tuple containing the total reward and a dictionary of each individual reward component.
    """
    # Negative squared distance from the current displacement to the target displacement
    displacement_error = current_palm_displacement - torch.tensor(target_displacement, device=current_palm_displacement.device)

    # Reward based on how close the current displacement is to the target displacement;
    # Using squared error to penalize larger deviations more harshly
    displacement_reward = -torch.pow(displacement_error, 2)
    
    # Total reward
    total_reward = displacement_reward

    # Reward components dictionary
    reward_components = {
        "displacement_reward": displacement_reward,
    }

    return total_reward, reward_components
