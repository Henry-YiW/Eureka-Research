@torch.jit.script
def compute_reward(current_palm_displacement: torch.Tensor, target_displacement: torch.Tensor) -> torch.Tensor:
    # Parameters for reward calculation
    displacement_error_temp: float = 5.0
    
    # Calculate displacement error
    displacement_error = torch.norm(current_palm_displacement - target_displacement)
    
    # Compute exponential decay of error to encourage proximity to target displacement
    reward = torch.exp(-displacement_error_temp * displacement_error)
    
    # Prepare dictionary for debugging purposes containing individual components
    debug_info = {
        "displacement_error": displacement_error,
        "current_palm_displacement": current_palm_displacement,
        "target_displacement": target_displacement
    }
    
    return reward, debug_info
