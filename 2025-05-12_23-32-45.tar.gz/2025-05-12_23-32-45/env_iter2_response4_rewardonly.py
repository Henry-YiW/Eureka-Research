@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_displacement: float) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Temperature parameters for the exponential transformation
    displacement_temperature: float = 0.1
    
    # Compute the difference between current displacement and the target displacement
    displacement_diff = torch.abs(current_palm_displacement - target_displacement)
    
    # Apply an exponential transformation to the negative of the difference to form the reward
    # This will ensure the reward is higher when the displacement difference is smaller
    reward = torch.exp(-displacement_diff / displacement_temperature)
    
    # Collect individual component of the reward for debugging or analysis
    reward_components: Dict[str, Tensor] = {
        "raw_displacement_diff": displacement_diff,
        "exponential_reward_component": reward
    }
    
    return torch.mean(reward), reward_components
