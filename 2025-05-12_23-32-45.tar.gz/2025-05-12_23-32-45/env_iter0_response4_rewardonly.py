@torch.jit.script
def compute_reward(
    current_palm_displacement: Tensor,
    target_displacement: float,
    rope_velocity: Tensor
) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Component reward temperatures
    displacement_temp: float = 0.1  # Temperature for displacement error scaling
    velocity_temp: float = 0.05  # Temperature for velocity error scaling

    # Calculate the displacement error
    displacement_error: Tensor = torch.abs(current_palm_displacement - target_displacement)
    
    # Velocity error (magnitude of the rope's linear velocity, minimize to stabilize)
    velocity_error: Tensor = torch.norm(rope_velocity, dim=1)

    # Calculate individual negative exponential rewards for smoother convergence
    displacement_reward: Tensor = torch.exp(-displacement_error * displacement_temp)
    velocity_reward: Tensor = torch.exp(-velocity_error * velocity_temp)

    # Combine components into a total reward
    total_reward: Tensor = displacement_reward + velocity_reward

    # Returning the total reward and a dictionary of components for possibly debugging or analysis
    reward_components: Dict[str, Tensor] = {
        "displacement_reward": displacement_reward,
        "velocity_reward": velocity_reward,
        "displacement_error": displacement_error,
        "velocity_error": velocity_error
    }

    return total_reward, reward_components
