@torch.jit.script
def compute_reward(current_displacement: torch.Tensor, target_displacement: float) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    temperature = 0.1  # this could be adjusted based on experimentation
    
    # Calculate the discrepancy between the current displacement and the target displacement
    displacement_error = torch.abs(current_displacement - target_displacement)

    # Transform the displacement error into a negative exponential reward component
    # This transformation represents that the closer the current displacement is to the target, the higher the reward.
    reward_displacement = -torch.exp(displacement_error / temperature)

    # Total reward
    total_reward = reward_displacement

    # Reward components for potential debugging or additional insights
    reward_components = {"reward_displacement": reward_displacement, "displacement_error": displacement_error}

    return total_reward, reward_components
