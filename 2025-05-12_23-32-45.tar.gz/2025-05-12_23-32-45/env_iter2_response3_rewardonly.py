@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_displacement: float) -> Tuple[Tensor, Dict[str, Tensor]]:
    displacement_error = (current_palm_displacement - target_displacement).abs()
    
    # Normalizing the error to a smaller range using an exponential decay can be more beneficial for learning - less harsh for smaller errors
    error_temperature = 0.1  # Temperature for tuning how harsh the reward reaction is
    reward_displacement = torch.exp(-error_temperature * displacement_error)

    # Total reward is defined as a negative of the error norm
    total_reward = reward_displacement

    # Collecting individual components
    detailed_rewards = {
        "reward_displacement": reward_displacement
    }

    return total_reward, detailed_rewards
