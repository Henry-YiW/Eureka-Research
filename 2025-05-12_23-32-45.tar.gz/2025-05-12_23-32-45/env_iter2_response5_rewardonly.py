@torch.jit.script
def compute_reward(current_palm_displacement: torch.Tensor, target_displacement: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    # Temperature variable for displacement error
    displacement_temp: float = 10.0

    # Calculate the squared error of the displacement, encourage the palm to be at the target displacement
    displacement_error: torch.Tensor = torch.pow(current_palm_displacement - target_displacement, 2)
    reward_displacement: torch.Tensor = -torch.exp(displacement_error * displacement_temp)

    # Total reward is the displacement reward
    total_reward: torch.Tensor = reward_displacement

    # Collect individual components of the reward for debugging or analysis
    reward_dict: Dict[str, torch.Tensor] = {
        "reward_displacement": reward_displacement,
        "displacement_error": displacement_error
    }

    return total_reward, reward_dict
