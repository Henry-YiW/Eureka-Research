@torch.jit.script
def compute_reward(current_palm_displacement: torch.Tensor, target_displacement: float) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    # Constants
    distance_temperature: float = 0.1
    displacement_penalty_temperature: float = 0.01

    # Compute the absolute displacement error
    displacement_error = torch.abs(current_palm_displacement - target_displacement)

    # Reward for being close to the target displacement
    displacement_reward = torch.exp(-displacement_penalty_temperature * displacement_error)

    # Total reward
    total_reward = displacement_reward

    # Dictionary of reward components
    reward_components = {
        "displacement_reward": displacement_reward,
        "displacement_error": displacement_error
    }

    return total_reward, reward_components
