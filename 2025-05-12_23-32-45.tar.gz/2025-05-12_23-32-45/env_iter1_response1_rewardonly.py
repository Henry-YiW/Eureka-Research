@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_displacement: Tensor) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Define temperature parameters for exponential transformation of the distance
    temperature: float = 0.1
    
    # Calculate the absolute difference in displacement (error)
    displacement_error = torch.abs(current_palm_displacement - target_displacement)
    
    # Transforming the error using an exponential function to provide a reward
    # The greater the error, the lower the reward
    transformed_reward = torch.exp(-displacement_error / temperature)
    
    # Total reward is the mean of all transformed rewards
    reward = torch.mean(transformed_reward)
    
    # Collect components for debug or analysis
    reward_components = {
        "displacement_error": displacement_error,
        "transformed_reward": transformed_reward
    }
    
    return reward, reward_components
