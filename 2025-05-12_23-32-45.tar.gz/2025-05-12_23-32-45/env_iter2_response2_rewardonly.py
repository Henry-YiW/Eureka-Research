@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_displacement: float) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Rover-specific variables and reward
    displacement_error = torch.abs(current_palm_displacement - target_displacement)
    
    # Reward for reducing the distance to the target displacement
    displacement_reward_temperature = 0.1  # A temperature factor to scale the exponential reward
    displacement_reward = torch.exp(-displacement_error / displacement_reward_temperature)

    # Calculate total reward
    total_reward = displacement_reward.clone()
    
    # Rewards dictionary for detailed insights
    rewards_dict = {
        "displacement_reward": displacement_reward,
        "displacement_error": displacement_error
    }

    return total_reward, rewards_dict
