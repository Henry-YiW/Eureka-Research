@torch.jit.script
def compute_reward(current_palm_displacement: Tensor, target_palm_displacement: Tensor) -> Tuple[Tensor, Dict[str, Tensor]]:
    # Constants used for shaping and sensitivity of the reward
    displacement_scale: float = 1.0  # Scales the displacement for computing reward
    reward_temperature: float = 0.1  # Temperature parameter for exponential reward scaling

    # Error between the current displacement and the target displacement
    displacement_error: Tensor = torch.abs(current_palm_displacement - target_palm_displacement)

    # Computing the negative exponential of the scaled error
    reward: Tensor = torch.exp(-displacement_error / displacement_scale / reward_temperature)

    # Component dictionary should have clear names for easy debugging and analysis
    reward_components: Dict[str, Tensor] = {
        "displacement_reward": reward
    }

    # Total reward computation as a sum of all components
    total_reward: Tensor = torch.sum(reward)

    return total_reward, reward_components
