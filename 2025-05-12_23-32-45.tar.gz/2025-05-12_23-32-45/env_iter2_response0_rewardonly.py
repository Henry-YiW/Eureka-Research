@torch.jit.script
def compute_reward(current_palm_displacement: torch.Tensor, target_displacement: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    # Difference between the current displacement and the target displacement
    displacement_error = torch.abs(current_palm_displacement - target_displacement)

    # Convert the error into a negative exponential reward to incentivize minimizing the error
    error_temperature: float = 0.1  # Smaller temperature makes the reward function sharper
    reward_error = torch.exp(-displacement_error / error_temperature)

    # Calculate the total reward, which could be more complex if multiple components are considered
    total_reward = torch.mean(reward_error)

    reward_components = {
        "displacement_error": displacement_error,
        "reward_error": reward_error
    }

    return total_reward, reward_components
