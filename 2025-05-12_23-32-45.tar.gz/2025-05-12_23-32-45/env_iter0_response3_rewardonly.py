@torch.jit.script
def compute_reward(current_palm_displacement: torch.Tensor, target_displacement: float) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """
    Computes the reward for moving the rope to achieve a target displacement.

    Args:
    - current_palm_displacement (torch.Tensor): The current displacement of the palm from its initial position along the y-axis.
    - target_displacement (float): The target displacement along the y-axis of the rope through the shadow hand.

    Returns:
    - Tuple containing the total reward and a dictionary of reward components.
    """
    # Ensure the displacement and target are on the same device and of the same type
    device = current_palm_displacement.device
    dtype = current_palm_displacement.dtype
    target_tensor = torch.tensor(target_displacement, device=device, dtype=dtype)

    # Calculate the displacement error (distance from the target displacement)
    displacement_error = torch.abs(current_palm_displacement - target_tensor)

    # Reward component for reaching close to or at the target displacement
    reward_displacement = -displacement_error

    # Transform reward with temperature to emphasize errors near zero
    temp_displacement = 0.1
    reward_displacement = torch.exp(reward_displacement / temp_displacement)

    # Aggregate the total reward
    total_reward = reward_displacement
    
    # Pack reward components in a dictionary for potential debugging/analysis
    reward_dict = {
        "reward_displacement": reward_displacement,
        "displacement_error": displacement_error
    }
    
    return total_reward, reward_dict
